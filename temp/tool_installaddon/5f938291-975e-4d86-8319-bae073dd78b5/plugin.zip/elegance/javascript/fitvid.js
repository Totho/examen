/*
 FitVid will dynamically fit embedded video in Moodle
*/
  $(document).ready(function(){
    $(".mediaplugin").fitVids();
  });
